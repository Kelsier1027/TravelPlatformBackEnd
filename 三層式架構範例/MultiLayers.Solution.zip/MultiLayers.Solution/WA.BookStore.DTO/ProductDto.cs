﻿namespace WA.BookStore.DTO
{
	public class ProductDto
	{
	}
}