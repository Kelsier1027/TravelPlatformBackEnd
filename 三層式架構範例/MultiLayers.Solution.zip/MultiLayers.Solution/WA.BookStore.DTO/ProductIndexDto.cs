﻿namespace WA.BookStore.DTO
{
	public class ProductIndexDto
	{ }
}