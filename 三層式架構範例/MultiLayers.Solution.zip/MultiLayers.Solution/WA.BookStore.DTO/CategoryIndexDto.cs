﻿namespace WA.BookStore.DTO
{
	public class CategoryIndexDto
	{
		
	}
}