﻿using WA.BookStore.IDAL;

namespace WA.BookStore.DAL.ADO
{
	public class ProductADORepository : IProductRepository
	{
	}
}