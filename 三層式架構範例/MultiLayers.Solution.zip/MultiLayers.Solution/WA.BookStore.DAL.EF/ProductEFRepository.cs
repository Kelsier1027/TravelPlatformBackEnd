﻿using WA.BookStore.IDAL;

namespace WA.BookStore.DAL.EF
{
	public class ProductEFRepository : IProductRepository
	{
	}
}