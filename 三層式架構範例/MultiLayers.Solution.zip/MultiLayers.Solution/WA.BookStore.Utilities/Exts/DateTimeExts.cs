﻿namespace WA.BookStore.Utilities.Exts
{
	public static class DateTimeExts
	{
	}
}