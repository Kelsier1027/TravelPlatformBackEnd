﻿namespace WA.BookStore.IBLL
{
	public interface IProductService
	{
	}
}