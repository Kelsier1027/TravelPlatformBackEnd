﻿using WA.BookStore.IDAL;

namespace WA.BookStore.DAL.DapperLib
{
	public class ProductDapperRepository : IProductRepository
	{
	}
}