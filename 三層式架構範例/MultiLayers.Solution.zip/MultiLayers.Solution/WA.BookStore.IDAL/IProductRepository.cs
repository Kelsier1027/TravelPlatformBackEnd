﻿namespace WA.BookStore.IDAL
{
	public interface IProductRepository
	{
	}
}