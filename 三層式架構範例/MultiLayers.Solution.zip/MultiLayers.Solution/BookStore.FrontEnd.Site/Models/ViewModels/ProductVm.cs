﻿namespace BookStore.FrontEnd.Site.Models.ViewModels
{
	public class ProductVm
	{
	}
}