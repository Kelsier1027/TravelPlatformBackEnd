﻿using System;
using System.Collections.Generic;
using WA.BookStore.DTO;
using WA.BookStore.IBLL;

namespace WA.BookStore.BLL
{
	public class ProductService : IProductService
	{
		public void Create(ProductDto dto)
		{
			throw new NotImplementedException();
		}

		public void Update(ProductDto dto)
		{
			throw new NotImplementedException();
		}

		public List<ProductDto> Search(string name)
		{
			throw new NotImplementedException();
		}
	}
}