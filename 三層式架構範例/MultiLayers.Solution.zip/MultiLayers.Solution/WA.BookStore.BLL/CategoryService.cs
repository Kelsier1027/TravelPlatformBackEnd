﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WA.BookStore.DTO;
using WA.BookStore.IBLL;

namespace WA.BookStore.BLL
{
    public class CategoryService:ICategoryService
    {
	    public void Create(CategoryDto dto)
	    {
		    throw new NotImplementedException();
	    }

	    public void Update(CategoryDto dto)
	    {
		    throw new NotImplementedException();
	    }

	    public List<CategoryIndexDto> Search(string name)
	    {
		    throw new NotImplementedException();
	    }
    }
}
